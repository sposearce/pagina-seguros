const express = require("express");

const router = express.Router();

const { verifyToken } = require("../middleware/jwt-validate");

const listaDeTareas = [
  {
    titulo: "Inicio de Cotizacion",
    prioridad: "prioridad-baja",
    autor: "Sistema OK",
  },
];

router.get("/", (req, res) => {
  res.send({
    tareas: listaDeTareas,
  });
});

router.post("/", verifyToken, (req, res) => {
  const titulo = req.body.titulo;
  const prioridad = req.body.prioridad;

  const nuevaTarea = {
    titulo: titulo,
    prioridad,
    autor: req.user.name,
  };

  listaDeTareas.push(nuevaTarea);

  res.send({
    tareas: listaDeTareas,
    tareaNueva: nuevaTarea,
  });
});

module.exports = {
  router: router,
  listaDeTareas: listaDeTareas,
};
